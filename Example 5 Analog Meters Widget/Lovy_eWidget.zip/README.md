# TFT_eWidget

An Arduino IDE compatible TFT GUI widget library to add functionality to TFT_eSPI.
