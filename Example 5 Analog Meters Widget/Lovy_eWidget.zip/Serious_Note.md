Please note: This is a modified version of the original TFT_eWidget library by Bodmer

Just the Meter part was changed for demonstration how a library can get modified.

All rights and credits are going to the original author, Bodmer.

It can be used with the LolyanGFX display library and again, just the 'Meter' part
is available.

LolyanGFX is available here: https://github.com/lovyan03/LovyanGFX
